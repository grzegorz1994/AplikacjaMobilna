package com.example.organizerrolnika;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MenuPolaActivity extends AppCompatActivity implements View.OnClickListener{

    private Button mNowyZabiegBtn;
    private Button mZbiorPlonowRtn;
    private Button mInformacjeOPoluBtn;
    private Button mNotatkiDoPolaBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_pola);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Menu pola");
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);

        mNowyZabiegBtn = (Button) findViewById(R.id.mNowyZabiegBtnMenuPola);
        mZbiorPlonowRtn = (Button) findViewById(R.id.mZbieraniePlonow_BtnMenuPola);
        mInformacjeOPoluBtn = (Button) findViewById(R.id.mInformacjeOPolu_BtnMenuPola);
        mNotatkiDoPolaBtn = (Button) findViewById(R.id.mNotatkiDoPola_BtnMenuPola);
        mNowyZabiegBtn.setOnClickListener(this);
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }

    @Override
    public void onClick(View v) {
        if (v == mNowyZabiegBtn){
            startActivity(new Intent(this, WybierzZabiegActivity.class));
        }
    }
}
