package com.example.organizerrolnika;

public class Pole {

    private String nazwaPola;
    private String rodzajUprawy;
    private String powierzchniaPola;

    public Pole(){}

    public Pole(String nazwaPola, String rodzajUprawy, String powierzchniaPola){
        this.nazwaPola = nazwaPola;
        this.rodzajUprawy = rodzajUprawy;
        this.powierzchniaPola = powierzchniaPola;
    }


    public String getNazwaPola(){
        return nazwaPola;
    }

    public String getRodzajUprawy(){
        return rodzajUprawy;
    }

    public String getPowierzchniaPola(){
        return powierzchniaPola;
    }
}
