package com.example.organizerrolnika;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class WybierzZabiegActivity extends AppCompatActivity implements View.OnClickListener{

    private Button mNawozenie;
    private Button mOchrona;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wybierz_zabieg);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Wybierz zabieg");
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);

        mNawozenie = (Button) findViewById(R.id.nawozenieBtn);
        mOchrona = (Button) findViewById(R.id.ochronaBtn);
        mNawozenie.setOnClickListener(this);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }

    @Override
    public void onClick(View v) {
        if (v == mNawozenie){
            startActivity(new Intent(this, RodzajNawozeniaActivity.class));
        }
    }
}
